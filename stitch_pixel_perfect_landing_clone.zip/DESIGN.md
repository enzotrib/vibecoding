---
name: Kinetic Dark
colors:
  surface: '#11131b'
  surface-dim: '#11131b'
  surface-bright: '#373941'
  surface-container-lowest: '#0c0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d1f27'
  surface-container-high: '#282a32'
  surface-container-highest: '#33343d'
  on-surface: '#e2e1ed'
  on-surface-variant: '#c3c5d7'
  inverse-surface: '#e2e1ed'
  inverse-on-surface: '#2e3038'
  outline: '#8d90a0'
  outline-variant: '#434654'
  surface-tint: '#b5c4ff'
  primary: '#b5c4ff'
  on-primary: '#00297a'
  primary-container: '#638aff'
  on-primary-container: '#00236b'
  inverse-primary: '#1653d6'
  secondary: '#ffb4a4'
  on-secondary: '#640c00'
  secondary-container: '#8c1802'
  on-secondary-container: '#ff9a85'
  tertiary: '#ffb688'
  on-tertiary: '#512400'
  tertiary-container: '#e07313'
  on-tertiary-container: '#471e00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b5c4ff'
  on-primary-fixed: '#00174c'
  on-primary-fixed-variant: '#003dab'
  secondary-fixed: '#ffdad3'
  secondary-fixed-dim: '#ffb4a4'
  on-secondary-fixed: '#3e0500'
  on-secondary-fixed-variant: '#8c1802'
  tertiary-fixed: '#ffdbc7'
  tertiary-fixed-dim: '#ffb688'
  on-tertiary-fixed: '#311300'
  on-tertiary-fixed-variant: '#733600'
  background: '#11131b'
  on-background: '#e2e1ed'
  surface-variant: '#33343d'
typography:
  h1:
    fontFamily: Manrope
    fontSize: 64px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  h2:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.03em
  h3:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0em
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0em
  label-sm:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  section-gap: 120px
  grid-gutter: 24px
  card-padding: 32px
  unit: 8px
---

## Brand & Style

This design system is built for high-performance SaaS and developer-centric platforms. It prioritizes a sophisticated, immersive environment that feels technically advanced yet approachable. The style is a hybrid of **Minimalism** and **Glassmorphism**, leveraging deep atmospheric depth through light-emitting elements and high-contrast typography. 

The aesthetic is defined by a "Luminous Dark" approach—where the interface doesn't just sit on a background but feels like a curated light-stage. It evokes a sense of power, speed, and precision, targeting users who value clean, intentional engineering and modern aesthetics.

## Colors

The palette is anchored by an ultra-deep charcoal background, providing the necessary contrast for electric highlights. 

- **Primary & Glows**: Electric Blue (#4D7CFF) acts as the primary action color. It is often paired with a purple-tinted blue for gradients to create "depth-lighting."
- **Accents**: A vibrant orange-red is used sparingly for high-impact emphasis and to provide visual warmth against the cool dark tones.
- **Surface Strategy**: Containers use deep slate/charcoal tones, separated from the background by razor-thin, low-opacity borders rather than heavy shadows.
- **Atmospherics**: Large, soft radial blurs in the background (15-25% opacity) should be positioned behind key content areas to create a sense of three-dimensional space.

## Typography

This design system utilizes **Manrope** for its technical yet geometric qualities. 

- **Headlines**: Large-scale headings must use tight tracking (letter-spacing) to appear impactful and integrated. Use high-contrast white (#FFFFFF) for primary headlines, and the vibrant gradient for key emphasis words.
- **Body**: Body text should use a slightly reduced opacity (70-80% white) to maintain visual hierarchy and reduce eye strain against the dark background.
- **Labels**: Small labels and navigation items should be clean and clear, often appearing in medium weights to ensure legibility.

## Layout & Spacing

The layout philosophy follows a **Fixed Grid** model for desktop, centered within the viewport to maintain focus.

- **Rhythm**: All spacing is derived from a base unit of 8px. 
- **The Grid**: Utilize a 12-column grid with generous 24px gutters. 
- **Patterning**: A subtle dot grid pattern (2px dots, 24px spacing, 10% opacity) should overlay the background to give the UI a "blueprint" or technical feel.
- **Whitespace**: Generous vertical margins (120px+) between major sections ensure that the luminous accents have room to breathe and don't feel cluttered.

## Elevation & Depth

Depth in this design system is created through **Tonal Layers** and **Backdrop Blurs** rather than traditional drop shadows.

- **Level 0 (Background)**: #0B0E14 with dot pattern.
- **Level 1 (Sub-containers)**: Subtle borders (#212836) with 0% fill, or ultra-low opacity fills (5%).
- **Level 2 (Active Tiles)**: These utilize inner glows and vibrant backdrop colors to "lift" off the page.
- **Glows**: Instead of black shadows, use tinted "Outer Glows" for primary buttons and active states. For example, a blue button should have a soft 20px blur of #4D7CFF at 30% opacity beneath it.

## Shapes

The shape language is consistently **Rounded**. 

- **Standard Radius**: 0.5rem (8px) for buttons and small inputs.
- **Large Radius**: 1rem (16px) for cards and main feature containers.
- **Icon Tiles**: Small tiles that house icons should use the standard 8px radius to maintain a modular, grid-aligned look.

## Components

### Buttons
- **Primary**: High-contrast blue gradient background, white text, 8px radius, and a subtle drop-shadow glow matching the primary blue.
- **Secondary**: Thin 1px border (#212836), white text, and a transparent background that blurs the layer behind it.
- **Icon Buttons**: Circular or soft-square with low-opacity fills and high-contrast white icons.

### Cards & Tiles
- **Standard Cards**: 1px border (#212836), no background fill (transparent), or very dark slate (#121721).
- **Iconography Tiles**: Square tiles with 8px radius. Active tiles feature a vibrant gradient background with high-quality white icons (e.g., SVG logos).

### Input Fields
- Deep charcoal fill with a subtle 1px border. On focus, the border transitions to primary blue with a faint outer glow.

### Chips & Badges
- Small, pill-shaped elements with a low-opacity primary blue fill and 14px medium-weight text. Often includes a small leading icon (e.g., a lightning bolt or checkmark).